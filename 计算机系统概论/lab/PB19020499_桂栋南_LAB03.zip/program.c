#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
struct node {
    int data;
    struct node *next;
    };
struct node *head;

void print(int a,int b, int c)
{
	
	int i;
	printf("RowA:");
	for(i=0;i<a;i++)
	printf("o");
	printf("\n");
	printf("RowB:");
	for(i=0;i<b;i++)
	printf("o");
	printf("\n");
	printf("RowC:");
	for(i=0;i<c;i++)
	printf("o");
	printf("\n");
}

void lab04()
{
	int a=3,b=5,c=8;
	int j=0;
	char char1,char2,char3;
	print(a,b,c);
	while(a!=0||b!=0||c!=0)
	{
	printf("Player %d, choose a row and number of rocks:",j+1);
	char1=getchar();
	char2=getchar();
	char3=getchar();
	if(char1=='A'&&a!=0&&char2>'0'&&(char2-'0')<=a)
	a=a-(char2-'0');
	else if(char1=='B'&&b!=0&&char2>'0'&&(char2-'0')<=b)
	b=b-(char2-'0');
	else if(char1=='C'&&c!=0&&char2>'0'&&(char2-'0')<=c)
	c=c-(char2-'0');
	else
	{
		printf("Invalid move. Try again.\n");
		continue;
	}
	j=(j+1)%2;
	if(a==0&&b==0&&c==0)
	break;
	print(a,b,c);
	
	}
	
	printf("Player %d wins.\n",j+1);
}

void lab02()
{
	int a,b,c,d,e;
	printf("Please input the two numbers:");
	scanf("%d%d",&a,&b);
	d=a;
	e=c=b;
	if(a<=0||b<=0)
	{
		printf("Invalid input.\n");
		exit(0);
	}
	if(a<b)
	{
		c=a;
		a=b;
		b=c;
	}
	while(c!=0)
	{
		c=a%b;
		a=b;
		b=c;
	}
	printf("GCD(%d,%d)=%d\n",d,e,a);
}

void lab03()
{
	int a,temp;
	struct node *p=NULL,*q=NULL,*first;
	do
	{
		printf("Please input the data of the linkist(0 means the end):");
		scanf("%d",&a);
		p=(struct node *)malloc(sizeof(struct node));
		p->data=a;
		if(q==NULL)
		first=q=p;
		else
		q->next=p;
		q=p;
	}while(a!=0);
	
	printf("The initial linklist:\n");
	for(p=first;p->data!=0;p=p->next)
	{
		printf("%d",p->data);
		printf("   --->  ");
	}
	printf("0\n");
	
	for(p=first;p->data!=0;p=p->next)
		for(q=first;q->next->data!=0;q=q->next)
		{
			if(q->data>q->next->data)
			{
				temp=q->data;
				q->data=q->next->data;
				q->next->data=temp;
			}
		}
		
	printf("NOTES:the final 0 is not sorted in this program!\n");
	printf("The linklist after sorting:\n");
	for(p=first;p->data!=0;p=p->next)
	{
		printf("%d",p->data);
		printf("   --->  ");
	}
	printf("0\n");
}

void lab05()
{
	while(1)
	{
		printf("ICS2020 ");
		int a=100000000;
		while(a>0)
		a--;
		char b;
		if (_kbhit())
		{
			//����а������£���_kbhit()����������
	        b= _getch();//ʹ��_getch()������ȡ���µļ�ֵ
	        if(b>='0'&&b<='9')
	        printf("\n%c is a decimal digit.\n",b);
	        else 
	        printf("\n%c is not a decimal digit.\n",b);
		}
	}
}

main()
{
	int a;
	while(1)
	{
		printf("\nPlease input the number of the lab(2~5):");
		scanf("%d",&a);
		switch(a)
		{
			case 2:lab02();break;
			case 3:lab03();break;
			case 4:getchar();lab04();break;
			case 5:lab05();break;
			default:exit(0);
		}
	}

	
 } 
